﻿namespace WindowsFormsApplication7
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LabelBasePrice = new System.Windows.Forms.Label();
            this.LabelAdditionalOptions = new System.Windows.Forms.Label();
            this.LabelSubTotal = new System.Windows.Forms.Label();
            this.LabelSalesTax = new System.Windows.Forms.Label();
            this.LabelTotal = new System.Windows.Forms.Label();
            this.LabelTradeIn = new System.Windows.Forms.Label();
            this.LabelAmountDue = new System.Windows.Forms.Label();
            this.TextBoxBasePrice = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.GroupBoxAdditionalItems = new System.Windows.Forms.GroupBox();
            this.CheckBoxComputerInterface = new System.Windows.Forms.CheckBox();
            this.CheckBoxLeatherInterior = new System.Windows.Forms.CheckBox();
            this.CheckBoxStereoSystem = new System.Windows.Forms.CheckBox();
            this.GroupBoxExteriorFinish = new System.Windows.Forms.GroupBox();
            this.RadioButtonCustomized = new System.Windows.Forms.RadioButton();
            this.RadioButtonPearlized = new System.Windows.Forms.RadioButton();
            this.RadioButtonStandard = new System.Windows.Forms.RadioButton();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.MainMenu.SuspendLayout();
            this.GroupBoxAdditionalItems.SuspendLayout();
            this.GroupBoxExteriorFinish.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainMenu
            // 
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(455, 25);
            this.MainMenu.TabIndex = 26;
            this.MainMenu.Text = "Main Menu";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.fileToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.F)));
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 21);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculateToolStripMenuItem,
            this.clearToolStripMenuItem,
            this.fontToolStripMenuItem,
            this.colorToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.editToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // calculateToolStripMenuItem
            // 
            this.calculateToolStripMenuItem.Name = "calculateToolStripMenuItem";
            this.calculateToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.calculateToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.calculateToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.calculateToolStripMenuItem.Text = "&Calculate";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.clearToolStripMenuItem.Text = "C&lear";
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.fontToolStripMenuItem.Text = "&Font";
            // 
            // colorToolStripMenuItem
            // 
            this.colorToolStripMenuItem.Name = "colorToolStripMenuItem";
            this.colorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.colorToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.colorToolStripMenuItem.Text = "C&olor";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(47, 21);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.aboutToolStripMenuItem.Text = "&About";
            // 
            // LabelBasePrice
            // 
            this.LabelBasePrice.AutoSize = true;
            this.LabelBasePrice.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelBasePrice.Location = new System.Drawing.Point(62, 45);
            this.LabelBasePrice.Name = "LabelBasePrice";
            this.LabelBasePrice.Size = new System.Drawing.Size(77, 14);
            this.LabelBasePrice.TabIndex = 27;
            this.LabelBasePrice.Text = "Base Price:";
            this.LabelBasePrice.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LabelAdditionalOptions
            // 
            this.LabelAdditionalOptions.AutoSize = true;
            this.LabelAdditionalOptions.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LabelAdditionalOptions.Location = new System.Drawing.Point(12, 75);
            this.LabelAdditionalOptions.Name = "LabelAdditionalOptions";
            this.LabelAdditionalOptions.Size = new System.Drawing.Size(127, 14);
            this.LabelAdditionalOptions.TabIndex = 28;
            this.LabelAdditionalOptions.Text = "Additional Options:";
            this.LabelAdditionalOptions.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LabelSubTotal
            // 
            this.LabelSubTotal.AutoSize = true;
            this.LabelSubTotal.Font = new System.Drawing.Font("Verdana", 9F);
            this.LabelSubTotal.Location = new System.Drawing.Point(73, 105);
            this.LabelSubTotal.Name = "LabelSubTotal";
            this.LabelSubTotal.Size = new System.Drawing.Size(66, 14);
            this.LabelSubTotal.TabIndex = 29;
            this.LabelSubTotal.Text = "SubTotal:";
            this.LabelSubTotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LabelSalesTax
            // 
            this.LabelSalesTax.AutoSize = true;
            this.LabelSalesTax.Font = new System.Drawing.Font("Verdana", 9F);
            this.LabelSalesTax.Location = new System.Drawing.Point(25, 139);
            this.LabelSalesTax.Name = "LabelSalesTax";
            this.LabelSalesTax.Size = new System.Drawing.Size(114, 14);
            this.LabelSalesTax.TabIndex = 30;
            this.LabelSalesTax.Text = "Sales Tax (13%):";
            this.LabelSalesTax.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LabelTotal
            // 
            this.LabelTotal.AutoSize = true;
            this.LabelTotal.Font = new System.Drawing.Font("Verdana", 9F);
            this.LabelTotal.Location = new System.Drawing.Point(97, 171);
            this.LabelTotal.Name = "LabelTotal";
            this.LabelTotal.Size = new System.Drawing.Size(42, 14);
            this.LabelTotal.TabIndex = 31;
            this.LabelTotal.Text = "Total:";
            this.LabelTotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LabelTradeIn
            // 
            this.LabelTradeIn.AutoSize = true;
            this.LabelTradeIn.Font = new System.Drawing.Font("Verdana", 9F);
            this.LabelTradeIn.Location = new System.Drawing.Point(9, 206);
            this.LabelTradeIn.Name = "LabelTradeIn";
            this.LabelTradeIn.Size = new System.Drawing.Size(130, 14);
            this.LabelTradeIn.TabIndex = 32;
            this.LabelTradeIn.Text = "Trade-in Allowance:";
            this.LabelTradeIn.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LabelAmountDue
            // 
            this.LabelAmountDue.AutoSize = true;
            this.LabelAmountDue.Font = new System.Drawing.Font("Verdana", 9F);
            this.LabelAmountDue.Location = new System.Drawing.Point(50, 239);
            this.LabelAmountDue.Name = "LabelAmountDue";
            this.LabelAmountDue.Size = new System.Drawing.Size(89, 14);
            this.LabelAmountDue.TabIndex = 33;
            this.LabelAmountDue.Text = "Amount Due:";
            this.LabelAmountDue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TextBoxBasePrice
            // 
            this.TextBoxBasePrice.Location = new System.Drawing.Point(145, 45);
            this.TextBoxBasePrice.Name = "TextBoxBasePrice";
            this.TextBoxBasePrice.Size = new System.Drawing.Size(100, 20);
            this.TextBoxBasePrice.TabIndex = 34;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(145, 75);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 35;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(145, 105);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 36;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(145, 139);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 37;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(145, 171);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 38;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(145, 206);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 39;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(145, 239);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 40;
            // 
            // GroupBoxAdditionalItems
            // 
            this.GroupBoxAdditionalItems.Controls.Add(this.CheckBoxComputerInterface);
            this.GroupBoxAdditionalItems.Controls.Add(this.CheckBoxLeatherInterior);
            this.GroupBoxAdditionalItems.Controls.Add(this.CheckBoxStereoSystem);
            this.GroupBoxAdditionalItems.Location = new System.Drawing.Point(286, 45);
            this.GroupBoxAdditionalItems.Name = "GroupBoxAdditionalItems";
            this.GroupBoxAdditionalItems.Size = new System.Drawing.Size(157, 129);
            this.GroupBoxAdditionalItems.TabIndex = 41;
            this.GroupBoxAdditionalItems.TabStop = false;
            this.GroupBoxAdditionalItems.Text = "Additional Items";
            // 
            // CheckBoxComputerInterface
            // 
            this.CheckBoxComputerInterface.AutoSize = true;
            this.CheckBoxComputerInterface.Location = new System.Drawing.Point(23, 102);
            this.CheckBoxComputerInterface.Name = "CheckBoxComputerInterface";
            this.CheckBoxComputerInterface.Size = new System.Drawing.Size(116, 17);
            this.CheckBoxComputerInterface.TabIndex = 2;
            this.CheckBoxComputerInterface.Text = "Computer Interface";
            this.CheckBoxComputerInterface.UseVisualStyleBackColor = true;
            // 
            // CheckBoxLeatherInterior
            // 
            this.CheckBoxLeatherInterior.AutoSize = true;
            this.CheckBoxLeatherInterior.Location = new System.Drawing.Point(23, 67);
            this.CheckBoxLeatherInterior.Name = "CheckBoxLeatherInterior";
            this.CheckBoxLeatherInterior.Size = new System.Drawing.Size(97, 17);
            this.CheckBoxLeatherInterior.TabIndex = 1;
            this.CheckBoxLeatherInterior.Text = "Leather Interior";
            this.CheckBoxLeatherInterior.UseVisualStyleBackColor = true;
            // 
            // CheckBoxStereoSystem
            // 
            this.CheckBoxStereoSystem.AutoSize = true;
            this.CheckBoxStereoSystem.Location = new System.Drawing.Point(23, 32);
            this.CheckBoxStereoSystem.Name = "CheckBoxStereoSystem";
            this.CheckBoxStereoSystem.Size = new System.Drawing.Size(94, 17);
            this.CheckBoxStereoSystem.TabIndex = 0;
            this.CheckBoxStereoSystem.Text = "Stereo System";
            this.CheckBoxStereoSystem.UseVisualStyleBackColor = true;
            // 
            // GroupBoxExteriorFinish
            // 
            this.GroupBoxExteriorFinish.Controls.Add(this.RadioButtonCustomized);
            this.GroupBoxExteriorFinish.Controls.Add(this.RadioButtonPearlized);
            this.GroupBoxExteriorFinish.Controls.Add(this.RadioButtonStandard);
            this.GroupBoxExteriorFinish.Location = new System.Drawing.Point(286, 180);
            this.GroupBoxExteriorFinish.Name = "GroupBoxExteriorFinish";
            this.GroupBoxExteriorFinish.Size = new System.Drawing.Size(164, 137);
            this.GroupBoxExteriorFinish.TabIndex = 42;
            this.GroupBoxExteriorFinish.TabStop = false;
            this.GroupBoxExteriorFinish.Text = "Exterior Finish";
            // 
            // RadioButtonCustomized
            // 
            this.RadioButtonCustomized.AutoSize = true;
            this.RadioButtonCustomized.Location = new System.Drawing.Point(23, 101);
            this.RadioButtonCustomized.Name = "RadioButtonCustomized";
            this.RadioButtonCustomized.Size = new System.Drawing.Size(123, 17);
            this.RadioButtonCustomized.TabIndex = 2;
            this.RadioButtonCustomized.Text = "Customized Detailing";
            this.RadioButtonCustomized.UseVisualStyleBackColor = true;
            // 
            // RadioButtonPearlized
            // 
            this.RadioButtonPearlized.AutoSize = true;
            this.RadioButtonPearlized.Location = new System.Drawing.Point(23, 67);
            this.RadioButtonPearlized.Name = "RadioButtonPearlized";
            this.RadioButtonPearlized.Size = new System.Drawing.Size(68, 17);
            this.RadioButtonPearlized.TabIndex = 1;
            this.RadioButtonPearlized.Text = "Pearlized";
            this.RadioButtonPearlized.UseVisualStyleBackColor = true;
            // 
            // RadioButtonStandard
            // 
            this.RadioButtonStandard.AutoSize = true;
            this.RadioButtonStandard.Checked = true;
            this.RadioButtonStandard.Location = new System.Drawing.Point(23, 33);
            this.RadioButtonStandard.Name = "RadioButtonStandard";
            this.RadioButtonStandard.Size = new System.Drawing.Size(68, 17);
            this.RadioButtonStandard.TabIndex = 0;
            this.RadioButtonStandard.TabStop = true;
            this.RadioButtonStandard.Text = "Standard";
            this.RadioButtonStandard.UseVisualStyleBackColor = true;
            // 
            // CalculateButton
            // 
            this.CalculateButton.BackColor = System.Drawing.Color.White;
            this.CalculateButton.Location = new System.Drawing.Point(28, 342);
            this.CalculateButton.Margin = new System.Windows.Forms.Padding(0);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(120, 30);
            this.CalculateButton.TabIndex = 42;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = false;
            // 
            // ClearButton
            // 
            this.ClearButton.BackColor = System.Drawing.Color.White;
            this.ClearButton.Location = new System.Drawing.Point(181, 342);
            this.ClearButton.Margin = new System.Windows.Forms.Padding(0);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(120, 30);
            this.ClearButton.TabIndex = 43;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = false;
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.White;
            this.ExitButton.Location = new System.Drawing.Point(323, 342);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(0);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(120, 30);
            this.ExitButton.TabIndex = 44;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 429);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.GroupBoxExteriorFinish);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.GroupBoxAdditionalItems);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.TextBoxBasePrice);
            this.Controls.Add(this.LabelAmountDue);
            this.Controls.Add(this.LabelTradeIn);
            this.Controls.Add(this.LabelTotal);
            this.Controls.Add(this.LabelSalesTax);
            this.Controls.Add(this.LabelSubTotal);
            this.Controls.Add(this.LabelAdditionalOptions);
            this.Controls.Add(this.LabelBasePrice);
            this.Controls.Add(this.MainMenu);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Auto Center";
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.GroupBoxAdditionalItems.ResumeLayout(false);
            this.GroupBoxAdditionalItems.PerformLayout();
            this.GroupBoxExteriorFinish.ResumeLayout(false);
            this.GroupBoxExteriorFinish.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label LabelBasePrice;
        private System.Windows.Forms.Label LabelAdditionalOptions;
        private System.Windows.Forms.Label LabelSubTotal;
        private System.Windows.Forms.Label LabelSalesTax;
        private System.Windows.Forms.Label LabelTotal;
        private System.Windows.Forms.Label LabelTradeIn;
        private System.Windows.Forms.Label LabelAmountDue;
        private System.Windows.Forms.TextBox TextBoxBasePrice;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.GroupBox GroupBoxAdditionalItems;
        private System.Windows.Forms.CheckBox CheckBoxComputerInterface;
        private System.Windows.Forms.CheckBox CheckBoxLeatherInterior;
        private System.Windows.Forms.CheckBox CheckBoxStereoSystem;
        private System.Windows.Forms.GroupBox GroupBoxExteriorFinish;
        private System.Windows.Forms.RadioButton RadioButtonCustomized;
        private System.Windows.Forms.RadioButton RadioButtonPearlized;
        private System.Windows.Forms.RadioButton RadioButtonStandard;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

