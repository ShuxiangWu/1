﻿namespace SlotMachine
{
    partial class SlotMachineForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SpinPictureBox = new System.Windows.Forms.PictureBox();
            this.jackpotBox = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.amount = new System.Windows.Forms.TextBox();
            this.credit = new System.Windows.Forms.TextBox();
            this.bet = new System.Windows.Forms.TextBox();
            this.close = new System.Windows.Forms.PictureBox();
            this.reset = new System.Windows.Forms.PictureBox();
            this.bet1 = new System.Windows.Forms.PictureBox();
            this.bet25 = new System.Windows.Forms.PictureBox();
            this.bet5 = new System.Windows.Forms.PictureBox();
            this.bet50 = new System.Windows.Forms.PictureBox();
            this.bet2 = new System.Windows.Forms.PictureBox();
            this.bet100 = new System.Windows.Forms.PictureBox();
            this.bet10 = new System.Windows.Forms.PictureBox();
            this.bet500 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.SpinPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet500)).BeginInit();
            this.SuspendLayout();
            // 
            // SpinPictureBox
            // 
            this.SpinPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.SpinPictureBox.Image = global::SlotMachine.Properties.Resources.spin;
            this.SpinPictureBox.Location = new System.Drawing.Point(349, 444);
            this.SpinPictureBox.Name = "SpinPictureBox";
            this.SpinPictureBox.Size = new System.Drawing.Size(60, 50);
            this.SpinPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SpinPictureBox.TabIndex = 6;
            this.SpinPictureBox.TabStop = false;
            this.SpinPictureBox.Click += new System.EventHandler(this.SpinPictureBox_Click);
            // 
            // jackpotBox
            // 
            this.jackpotBox.Enabled = false;
            this.jackpotBox.Location = new System.Drawing.Point(183, 163);
            this.jackpotBox.Name = "jackpotBox";
            this.jackpotBox.ReadOnly = true;
            this.jackpotBox.Size = new System.Drawing.Size(100, 20);
            this.jackpotBox.TabIndex = 7;
            this.jackpotBox.Text = "Jackpot";
            this.jackpotBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jackpotBox.TextChanged += new System.EventHandler(this.WutextBox1_TextChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SlotMachine.Properties.Resources.orange;
            this.pictureBox3.Location = new System.Drawing.Point(304, 229);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(75, 126);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SlotMachine.Properties.Resources.grapes;
            this.pictureBox2.Location = new System.Drawing.Point(193, 229);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 126);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SlotMachine.Properties.Resources.cherry;
            this.pictureBox1.Location = new System.Drawing.Point(80, 229);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 126);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // amount
            // 
            this.amount.Location = new System.Drawing.Point(289, 375);
            this.amount.Name = "amount";
            this.amount.ReadOnly = true;
            this.amount.Size = new System.Drawing.Size(90, 20);
            this.amount.TabIndex = 11;
            this.amount.Text = "amount";
            // 
            // credit
            // 
            this.credit.Location = new System.Drawing.Point(71, 375);
            this.credit.Name = "credit";
            this.credit.ReadOnly = true;
            this.credit.Size = new System.Drawing.Size(107, 20);
            this.credit.TabIndex = 12;
            this.credit.Text = "credit";
            // 
            // bet
            // 
            this.bet.Location = new System.Drawing.Point(193, 375);
            this.bet.Name = "bet";
            this.bet.ReadOnly = true;
            this.bet.Size = new System.Drawing.Size(62, 20);
            this.bet.TabIndex = 13;
            this.bet.Text = "bet";
            // 
            // close
            // 
            this.close.Image = global::SlotMachine.Properties.Resources.powerbutton;
            this.close.Location = new System.Drawing.Point(244, 440);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(48, 54);
            this.close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.close.TabIndex = 14;
            this.close.TabStop = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // reset
            // 
            this.reset.Image = global::SlotMachine.Properties.Resources.reset;
            this.reset.Location = new System.Drawing.Point(298, 442);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(54, 50);
            this.reset.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.reset.TabIndex = 15;
            this.reset.TabStop = false;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // bet1
            // 
            this.bet1.Image = global::SlotMachine.Properties.Resources.bet1;
            this.bet1.Location = new System.Drawing.Point(71, 430);
            this.bet1.Name = "bet1";
            this.bet1.Size = new System.Drawing.Size(34, 34);
            this.bet1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet1.TabIndex = 16;
            this.bet1.TabStop = false;
            this.bet1.Click += new System.EventHandler(this.bet1_Click);
            // 
            // bet25
            // 
            this.bet25.Image = global::SlotMachine.Properties.Resources.bet25;
            this.bet25.Location = new System.Drawing.Point(71, 470);
            this.bet25.Name = "bet25";
            this.bet25.Size = new System.Drawing.Size(34, 35);
            this.bet25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet25.TabIndex = 17;
            this.bet25.TabStop = false;
            this.bet25.Click += new System.EventHandler(this.bet25_Click);
            // 
            // bet5
            // 
            this.bet5.Image = global::SlotMachine.Properties.Resources.bet5;
            this.bet5.Location = new System.Drawing.Point(156, 430);
            this.bet5.Name = "bet5";
            this.bet5.Size = new System.Drawing.Size(37, 34);
            this.bet5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet5.TabIndex = 18;
            this.bet5.TabStop = false;
            this.bet5.Click += new System.EventHandler(this.bet5_Click);
            // 
            // bet50
            // 
            this.bet50.Image = global::SlotMachine.Properties.Resources.bet50;
            this.bet50.Location = new System.Drawing.Point(111, 470);
            this.bet50.Name = "bet50";
            this.bet50.Size = new System.Drawing.Size(39, 35);
            this.bet50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet50.TabIndex = 19;
            this.bet50.TabStop = false;
            this.bet50.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // bet2
            // 
            this.bet2.Image = global::SlotMachine.Properties.Resources.bet2;
            this.bet2.Location = new System.Drawing.Point(111, 430);
            this.bet2.Name = "bet2";
            this.bet2.Size = new System.Drawing.Size(39, 34);
            this.bet2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet2.TabIndex = 20;
            this.bet2.TabStop = false;
            this.bet2.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // bet100
            // 
            this.bet100.Image = global::SlotMachine.Properties.Resources.bet100;
            this.bet100.Location = new System.Drawing.Point(154, 470);
            this.bet100.Name = "bet100";
            this.bet100.Size = new System.Drawing.Size(39, 35);
            this.bet100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet100.TabIndex = 21;
            this.bet100.TabStop = false;
            this.bet100.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // bet10
            // 
            this.bet10.Image = global::SlotMachine.Properties.Resources.bet10;
            this.bet10.Location = new System.Drawing.Point(199, 430);
            this.bet10.Name = "bet10";
            this.bet10.Size = new System.Drawing.Size(41, 34);
            this.bet10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet10.TabIndex = 22;
            this.bet10.TabStop = false;
            this.bet10.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // bet500
            // 
            this.bet500.Image = global::SlotMachine.Properties.Resources.bet500;
            this.bet500.Location = new System.Drawing.Point(199, 470);
            this.bet500.Name = "bet500";
            this.bet500.Size = new System.Drawing.Size(39, 35);
            this.bet500.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bet500.TabIndex = 23;
            this.bet500.TabStop = false;
            this.bet500.Click += new System.EventHandler(this.bet500_Click);
            // 
            // SlotMachineForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::SlotMachine.Properties.Resources.slotmachine;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(462, 533);
            this.Controls.Add(this.bet500);
            this.Controls.Add(this.bet10);
            this.Controls.Add(this.bet100);
            this.Controls.Add(this.bet2);
            this.Controls.Add(this.bet50);
            this.Controls.Add(this.bet5);
            this.Controls.Add(this.bet25);
            this.Controls.Add(this.bet1);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.close);
            this.Controls.Add(this.bet);
            this.Controls.Add(this.credit);
            this.Controls.Add(this.amount);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.jackpotBox);
            this.Controls.Add(this.SpinPictureBox);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SlotMachineForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Slot Machine";
            this.Load += new System.EventHandler(this.SlotMachineForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SpinPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bet500)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox SpinPictureBox;
        private System.Windows.Forms.TextBox jackpotBox;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox amount;
        private System.Windows.Forms.TextBox credit;
        private System.Windows.Forms.TextBox bet;
        private System.Windows.Forms.PictureBox close;
        private System.Windows.Forms.PictureBox reset;
        private System.Windows.Forms.PictureBox bet1;
        private System.Windows.Forms.PictureBox bet25;
        private System.Windows.Forms.PictureBox bet5;
        private System.Windows.Forms.PictureBox bet50;
        private System.Windows.Forms.PictureBox bet2;
        private System.Windows.Forms.PictureBox bet100;
        private System.Windows.Forms.PictureBox bet10;
        private System.Windows.Forms.PictureBox bet500;
    }
}